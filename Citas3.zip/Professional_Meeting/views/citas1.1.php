<?php
require_once '../assets/conexion/servidor.php';

$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$conexion->query("SET NAMES 'utf8'");
$query =$conexion->prepare("SELECT * FROM mostrar_cita;");

$query->execute();
$resultado =$query->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Oasis</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_citas1.1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<?php include 'header_citas.php'; ?>

</head>
<body>
    


<div class="fondo">

<a class="btn btn-primary talleres" id="talleres" href="citas1.php">Registrar otra cita</a>

<h1 class="titulo_taller">Citas registradas</h1>

<table class="table-responsive">
    <thead>
<tr class="fila_principal">
    <td>Nombre del Especialista</td>
    <td>Nombre de Especialidad</td>
    <td>Fecha</td>
    <td>Hora</td>
    <td>Reservado</td>
</tr>
</thead>
<?php  foreach($resultado as $taller):  ?>

 

<tr class="filas_secundarias" id="color_gris" >
    <td> <a href="citas1.2.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"> <?php echo ($taller['NombreEspecialista']);?> </a></td>
    <td> <a href="citas1.2.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"> <?php echo ($taller['NombreEspecialidad']);?></a></td>
    <!--<td><a href="taller1.2.php?tallerista=<?php //echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php //echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php //echo $taller['Calendario']?>&turno=<?php //echo $taller['Turno']?>&dia=<?php //echo $taller['Dia']?>"><?php //echo $taller['Calendario']?></a></td>-->
    <td><a href="citas1.2.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $taller['Calendario']?></a></td>
  
    <td><a href="citas1.2.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $taller['Hora'].' horas'?></a></td>
    <td><a href="citas1.2.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $taller['Reservado']?></a></td>
  
    </tr>
</a>

<?php   endforeach; ?>

</table>

</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>

</body>
</html>
<?php $conexion = null;?>