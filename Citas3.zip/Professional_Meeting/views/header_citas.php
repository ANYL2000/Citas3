<style>
    .cabeza{
    display:flex !important;
}

.icono_udg{
    position: relative;
    margin-top: -30vh;
    margin-left: 4vw;
}

.titulo_pagina{
    position: relative;
    margin-left: -20vw;
   margin-top: -17vh;
   width: 100%;
     text-align: center;
     margin-right: 3vw;
    color: white;
    font-size:1.5rem !important;
    z-index: 10;
    font-family: Arial, Helvetica, sans-serif;
   
}

/*responsibidad*/

@media screen and (max-width: 1000px){
    
    button#consultar{
text-align: center;
margin-left: 50%;
margin-right: 3vw;
transform: translateX(-50%);
        margin-top: 2vw;
    }

    .taller_informacion{
      display: block;
    }
    .icono_udg{
        margin-top: -22vh;
        width:70%;
    }
    .titulo_pagina h1{
        margin-top: 6vh;
       margin-left: 20px;
        font-size: 30px;
    }
}

</style>


<div class="cabeza">
    <div><img class="icono_udg" src="" alt=""></div>
<div class="titulo_pagina"><h1 class="titulo">OASIS</h1></div>
</div>